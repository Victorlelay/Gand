library(questionr)
library(dplyr)
library(tidyr)

motifs <- c("indiv_immi0", "indiv_immi1", "indiv_immi2", "indiv_immi3", "indiv_immi4", "indiv_immi5", "indiv_immi6", "indiv_immi7", "indiv_immi8")
variables <- c("origine_tous_g2bis", "dip_rec", "religion_nomis", "sexee")

# Liste finale des tables combinées PAR indiv_immi
tables_combinees <- list()

for (df_name in motifs) {
  df <- get(df_name)
  resultats_var <- list()
  
  for (var in variables) {
    # Table non pondérée
    n_tab <- table(df[[var]], df$motif)
    df_n <- as.data.frame.matrix(n_tab)
    df_n$modalite <- rownames(df_n)
    df_n <- pivot_longer(df_n, -modalite, names_to = "motif", values_to = "n")
    
    # Table pondérée
    pond_tab <- wtd.table(df[[var]], df$motif, weights = df$poidsi)
    df_pct <- as.data.frame.matrix(round(prop.table(pond_tab, 2) * 100, 2))
    df_pct$modalite <- rownames(df_pct)
    df_pct <- pivot_longer(df_pct, -modalite, names_to = "motif", values_to = "pct")
    
    # Jointure sur modalite et motif
    tab <- left_join(df_n, df_pct, by = c("modalite", "motif"))
    
    # Ajout variable + source
    tab$variable <- var
    tab$source_df <- df_name
    
    resultats_var[[var]] <- tab
    
    # Test du chi²
    chi2_pval <- chisq.test(n_tab)$p.value
    assign(paste0("chi2_", var, "_", df_name), chi2_pval)
  }
  
  # Fusion verticale des résultats pour chaque dataframe
  tables_combinees[[df_name]] <- bind_rows(resultats_var)
}

table3 <- tables_combinees$indiv_immi3
write.csv(table3, "modalite3.csv", row.names = FALSE)
pond_tab <- wtd.table(indiv_immi3$origine_tous_g2bis, indiv_immi3$motif, weights = indiv_immi3$poidsi)
pct_tab <- round(prop.table(pond_tab, 2) * 100, 2)
pct_tab

table4 <- tables_combinees$indiv_immi4
write.csv(table4, "modalite4.csv", row.names = FALSE)
pond_tab <- wtd.table(indiv_immi3$origine_tous_g2bis, indiv_immi3$motif, weights = indiv_immi3$poidsi)
pct_tab <- round(prop.table(pond_tab, 2) * 100, 2)
pct_tab


table5 <- tables_combinees$indiv_immi5
write.csv(table5, "modalite5.csv", row.names = FALSE)

table6 <- tables_combinees$indiv_immi6
write.csv(table6, "modalite6.csv", row.names = FALSE)

table8 <- tables_combinees$indiv_immi8
write.csv(table8, "modalite8.csv", row.names = FALSE)

modalite_list <- lapply(tables_combinees, function(df) unique(df$modalite))

setdiff(modalite_list[[1]], modalite_list[[8]])
