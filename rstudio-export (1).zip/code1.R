library(dplyr)
library(questionr)
library(forcats)
# On s'occupe de la base filtrage
indiv_immi <- test_data
indiv_immi <- indiv_immi %>% mutate(origine_tous_g2bis = case_when(
  (origine_tous_g2 == 0 | origine_tous_g2 == 10 | origine_tous_g2 == 11) ~ "Pop maj", # population sans ascendance migratoire directe
  (origine_tous_g2 == 20) ~ "G1OM", # Originaires d'outre-mer
  (origine_tous_g2 == 22) ~ "G2OM", # Descendant.es d'originaires d'outre-mer
  (origine_tous_g2 == 30 | origine_tous_g2 == 40) ~ "G1Mag", # Immigré.es du Maghreb
  (origine_tous_g2 == 33 |origine_tous_g2 == 44) ~ "G2Mag", # Descendant.es d'immigré.es originaires du Maghreb
  (origine_tous_g2 == 50 | origine_tous_g2 == 60 | origine_tous_g2 == 70) ~ "G1Afr", # Immigré.es originaires d'Afrique Subsaharienne
  (origine_tous_g2 == 55 | origine_tous_g2 == 66 | origine_tous_g2 == 77) ~ "G2Afr", # Descendant.es d'immigré.es originaires d'Afrique Subsaharienne
  (origine_tous_g2 == 90) ~ "G1TurMO", # Immigré.es originaires de Turquie et du Moyen-Orient
  (origine_tous_g2 == 99) ~ "G2TurMO", # Descendant.es d'immigré.es originaires de Turquie et du Moyen-Orient
  (origine_tous_g2 == 80 | origine_tous_g2 == 100 | origine_tous_g2 == 110) ~ "G1Asi", # Immigré.es originaires du reste de l'Asie
  (origine_tous_g2 == 88 | origine_tous_g2 == 111) ~ "G2Asi", # Descendant.es d'immigré.es originaires de reste de l'Asie
  (origine_tous_g2 == 120 | origine_tous_g2 == 130 | origine_tous_g2== 140 | origine_tous_g2 == 150) ~ "G1Eur", # Immigré.es originaires d'Europe
  (origine_tous_g2 == 121 | origine_tous_g2 == 131 | origine_tous_g2 == 141 | origine_tous_g2 == 151) ~ "G2Eur", # Descendant.es d'originaires d'immigré.es d'Europe 
  (origine_tous_g2 == 160) ~ "G1Autre", # Immigré.es d'autres pays
  (origine_tous_g2 == 161) ~ "G2Autre", # Descendant.es d'immigré.es d'autres pays
  TRUE ~ NA_character_
))

indiv_immi <- indiv_immi %>% filter(origine_tous_g2bis!="Pop maj")


# On crée les variales sociodémographiques
# Avant après covid
indiv_immi$datenq_extr <- floor(indiv_immi$datenq / 100)
indiv_immi$datenq_extr2 <- floor(indiv_immi$datenq / 10000)
indiv_immi$datenq_extr3 <- indiv_immi$datenq_extr2 * 100
indiv_immi$monthnq <- indiv_immi$datenq_extr - indiv_immi$datenq_extr3

indiv_immi$pandemic <- 0
indiv_immi$pandemic[indiv_immi$monthnq > 2 & indiv_immi$aenq == 2020] <- 1
indiv_immi$pandemic[indiv_immi$aenq == 2021] <- 1

# Education
indiv_immi$dip_rec <- with(indiv_immi, ifelse(f_dip %in% 1:4, 1,
                                              ifelse(f_dip %in% 5:6, 2,
                                                     ifelse(f_dip %in% 7:8, 3, 1))))  # Les NA deviennent 1

indiv_immi$dip_rec <- factor(indiv_immi$dip_rec, levels = 1:3,
                             labels = c("<BAC", "BAC", ">BAC"))

# Revenu
mediane_valeurs <- c(300, 500, 700, 890, 1050, 1300, 1600, 1800, 2100, 2600, 3300, 4500, 6700, 11000, 2700, 2700)
indiv_immi$a_estim_rec <- NA
for (i in 1:14) {
  indiv_immi$a_estim_rec[indiv_immi$a_estim == i] <- mediane_valeurs[i]
}
indiv_immi$a_estim_rec[indiv_immi$a_estim %in% 98:99] <- 2700

# Remplacement des valeurs manquantes
indiv_immi$a_montan_rec <- indiv_immi$a_montan
indiv_immi$a_montan_rec[indiv_immi$a_montan_drap == -1] <- indiv_immi$a_estim_rec[indiv_immi$a_montan_drap == -1]

# Filtrage valeurs extrêmes
indiv_immi$a_montan_rec[indiv_immi$a_montan <= 495 | indiv_immi$a_montan > 11000] <- NA

# Création des tertiles
indiv_immi$income3 <- cut(indiv_immi$a_montan_rec,
                          breaks = quantile(indiv_immi$a_montan_rec, probs = seq(0, 1, by = 1/3), na.rm = TRUE),
                          include.lowest = TRUE, labels = FALSE)

# Religion
# Croyance religieuse
indiv_immi$religious <- indiv_immi$r_relsoi == 1

# Religion
indiv_immi$religion <- NA
indiv_immi$religion[indiv_immi$relego1 >= 10 & indiv_immi$relego1 <= 19] <- 1
indiv_immi$religion[indiv_immi$relego1 %in% c(20, 21)] <- 2
indiv_immi$religion[indiv_immi$relego1 >= 30] <- 3
indiv_immi$religion[indiv_immi$r_relsoi == 2 | indiv_immi$relego1 == 1] <- 4

indiv_immi$religion <- factor(indiv_immi$religion, levels = 1:4,
                              labels = c("Christian", "Muslim", "Other", "No current religion"))

# Ajout des non réponses
indiv_immi$religion_nomis <- NA
indiv_immi$religion_nomis[indiv_immi$relego1 >= 10 & indiv_immi$relego1 <= 19] <- 1
indiv_immi$religion_nomis[indiv_immi$relego1 %in% c(20, 21)] <- 2
indiv_immi$religion_nomis[indiv_immi$relego1 >= 30] <- 3
indiv_immi$religion_nomis[indiv_immi$r_relsoi != 1 | indiv_immi$relego1 == 1] <- 4

indiv_immi$religion_nomis <- factor(indiv_immi$religion_nomis, levels = 1:4,
                                    labels = c("Christian", "Muslim", "Other",
                                               "No current religion or no religion stated"))


# On crée la variable d'intérêt : MentalH
indiv_immi <- indiv_immi %>% mutate(MentalH = case_when(
  s_noplais==1|s_deprim==1 ~ 1,
  TRUE ~0
))

# On renomme les discriminations
indiv_immi <- indiv_immi %>%
  rename(
    Discri_age = d_pqdisc_a,
    Discri_genre = d_pqdisc_b,
    Discri_handi = d_pqdisc_c,
    Discri_peau = d_pqdisc_d,
    Discri_orig = d_pqdisc_e,
    Discri_quart = d_pqdisc_f,
    Discri_accent = d_pqdisc_g,
    Discri_fami = d_pqdisc_h,
    Discri_orientsex = d_pqdisc_i,
    Discri_relig = d_pqdisc_j,
    Discri_habi = d_pqdisc_k,
    Discri_poids = d_pqdisc_l,
    Discri_autre = d_pqdisc_m
  )


indiv_immi <- indiv_immi %>%
  mutate(across(starts_with("Discri_"), ~replace_na(., 0)))
indiv_immi <- indiv_immi %>%
  mutate(Discri = case)



# On crée la variable motif
indiv_immi <- indiv_immi %>% mutate(motif = case_when(
  Discri_age + Discri_genre + Discri_peau + Discri_orig + Discri_quart + Discri_accent + Discri_fami + Discri_orientsex + Discri_relig + Discri_habi + Discri_autre + Discri_handi + Discri_poids == 0 ~ 0,
  Discri_orig == 1 & Discri_peau + Discri_genre + Discri_relig  == 0 ~ 1,
  Discri_peau == 1 & Discri_genre + Discri_quart + Discri_accent + Discri_relig + Discri_orig == 0 ~ 2,
  Discri_relig == 1 & Discri_genre + Discri_quart + Discri_accent + Discri_peau + Discri_orig == 0 ~ 3,
  Discri_orig+Discri_peau == 2 & Discri_relig + Discri_genre == 0 ~ 4,
  Discri_orig+Discri_relig == 2 & Discri_genre + Discri_peau == 0 ~ 5,
  Discri_peau + Discri_relig == 2 & Discri_genre + Discri_quart + Discri_accent  + Discri_orig == 0 ~ 6,
  (Discri_peau==1|Discri_orig==1|Discri_quart==1|Discri_accent==1|Discri_relig==1) & Discri_genre ==1  ~ 7,
  TRUE ~ 8
))

# On règle un problème potentiel venant de l'importation d'une base stata
indiv_immi$sexee <- as_factor(indiv_immi$sexee)
# On fait une table par modalité
indiv_immi0 <- indiv_immi %>% filter(motif==0)
indiv_immi1 <- indiv_immi %>% filter(motif==1)
indiv_immi2 <- indiv_immi %>% filter(motif==2)
indiv_immi3 <- indiv_immi %>% filter(motif==3)
indiv_immi4 <- indiv_immi %>% filter(motif==4)
indiv_immi5 <- indiv_immi %>% filter(motif==5)
indiv_immi6 <- indiv_immi %>% filter(motif==6)
indiv_immi7 <- indiv_immi %>% filter(motif==7)
indiv_immi8 <- indiv_immi %>% filter(motif==8)
