library(questionr)
library(dplyr)
library(tidyr)


# Multi ethnoracial
indiv_immi<-indiv_immi %>% mutate(multiple_ethnoracial=case_when(
  Discri_age + Discri_genre + Discri_peau + Discri_orig + Discri_quart + Discri_accent + Discri_fami + Discri_orientsex + Discri_relig + Discri_habi + Discri_autre + Discri_handi + Discri_poids == 0 ~ 0,
  Discri_orig==1 & Discri_relig + Discri_peau == 0 ~ 1,
  Discri_peau==1 & Discri_orig + Discri_accent+ Discri_quart + Discri_relig == 0 ~2,
  Discri_relig==1 & Discri_orig + Discri_accent + Discri_quart + Discri_peau == 0 ~3,
  Discri_orig + Discri_peau == 2 & Discri_relig==0 ~ 4,
  Discri_orig + Discri_relig == 2 & Discri_peau == 0 ~5,
  Discri_peau + Discri_relig == 2 & Discri_orig + Discri_accent + Discri_quart == 0 ~6,
  (Discri_orig ==1 | Discri_accent==1 | Discri_quart==1) & Discri_relig + Discri_peau == 2 ~7,
  TRUE ~ 8
))

# On crée la table
# On fait une table par modalité
indiv_immi0 <- indiv_immi %>% filter(multiple_ethnoracial==0)
indiv_immi1 <- indiv_immi %>% filter(multiple_ethnoracial==1)
indiv_immi2 <- indiv_immi %>% filter(multiple_ethnoracial==2)
indiv_immi3 <- indiv_immi %>% filter(multiple_ethnoracial==3)
indiv_immi4 <- indiv_immi %>% filter(multiple_ethnoracial==4)
indiv_immi5 <- indiv_immi %>% filter(multiple_ethnoracial==5)
indiv_immi6 <- indiv_immi %>% filter(multiple_ethnoracial==6)
indiv_immi7 <- indiv_immi %>% filter(multiple_ethnoracial==7)
indiv_immi8 <- indiv_immi %>% filter(multiple_ethnoracial==8)


motifs <- c("indiv_immi0", "indiv_immi1", "indiv_immi2", "indiv_immi3", "indiv_immi4", "indiv_immi5", "indiv_immi6", "indiv_immi7", "indiv_immi8")
variables <- c("origine_tous_g2bis", "dip_rec", "religion_nomis", "sexee")

# Liste finale des tables combinées PAR indiv_immi
tables_combinees <- list()

for (df_name in motifs) {
  df <- get(df_name)
  resultats_var <- list()
  
  for (var in variables) {
    # Table non pondérée
    n_tab <- table(df[[var]], df$multiple_ethnoracial)
    df_n <- as.data.frame.matrix(n_tab)
    df_n$modalite <- rownames(df_n)
    df_n <- pivot_longer(df_n, -modalite, names_to = "motif", values_to = "n")
    
    # Table pondérée
    pond_tab <- wtd.table(df[[var]], df$multiple_ethnoracial, weights = df$poidsi)
    df_pct <- as.data.frame.matrix(round(prop.table(pond_tab, 2) * 100, 2))
    df_pct$modalite <- rownames(df_pct)
    df_pct <- pivot_longer(df_pct, -modalite, names_to = "motif", values_to = "pct")
    
    # Jointure sur modalite et motif
    tab <- left_join(df_n, df_pct, by = c("modalite", "motif"))
    
    # Ajout variable + source
    tab$variable <- var
    tab$source_df <- df_name
    
    resultats_var[[var]] <- tab
    
    # Test du chi²
    chi2_pval <- chisq.test(n_tab)$p.value
    assign(paste0("chi2_", var, "_", df_name), chi2_pval)
  }
  
  # Fusion verticale des résultats pour chaque dataframe
  tables_combinees[[df_name]] <- bind_rows(resultats_var)
}


table2 <- tables_combinees$indiv_immi2
write.csv(table2, "modalite22.csv", row.names = FALSE)