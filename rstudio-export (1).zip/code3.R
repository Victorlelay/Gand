# Pourcentages sur toute la population
table <- table(indiv_immi$motif, indiv_immi$origine_tous_g2bis)
table <- as.data.frame(table)
pond_tab <- wtd.table(indiv_immi$origine_tous_g2bis, weights = indiv_immi$poidsi)
pct_tab <- round(prop.table(pond_tab) * 100, 2)
pct_tab <- t(pct_tab)
pct_tab
write.csv(pct_tab, "pct.csv", row.names = FALSE)


chi2_pval <- chisq.test(table)$p.value


#####
# Ques les discriminé.es
discri <- indiv_immi %>% filter(motif!=0)




table <- wtd.table(discri$motif, discri$religion_nomis, weights = discri$poidsi)
pct_tab <- round(prop.table(table, 2) * 100, 2)
pct_tab <- t(pct_tab)
pct_tab
write.csv(pct_tab, "pct_relig2.csv", row.names = FALSE)
table <- table(discri$motif, discri$religion_nomis)
chi2_pval <- chisq.test(table)$p.value


table <- table(discri$religion_nomis)
table
table <- wtd.table(discri$religion_nomis,weights = discri$poidsi)
pct_tab <- round(prop.table(table) * 100, 2)
pct_tab

#######################
tab <- table(indiv_immi0$origine_tous_g2bis)
write.csv(tab, "n0.csv", row.names = FALSE)